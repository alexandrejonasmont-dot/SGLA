# Corrigir o erro de login

## O que está acontecendo

A base do sistema foi recriada nesta sessão. Numa base nova, o acesso por e-mail e senha vem **desligado** e o botão "Continuar com Google" ainda não tem o provedor habilitado. Por isso qualquer tentativa de entrar ou criar conta na tela de acesso falha, mesmo com os dados corretos.

O restante da estrutura de contas está correto: a criação automática do perfil do usuário no momento do cadastro já está ativa.

## O que será feito

1. Ligar o acesso por e-mail e senha na base do sistema.
2. Habilitar a entrada com Google, para o botão da tela de acesso funcionar.
3. Testar na prática: criar uma conta de teste, sair e entrar de novo, confirmando que o painel abre.
4. Ajustar as mensagens de erro da tela de acesso para mostrarem um texto claro em português (hoje aparece a mensagem técnica original) e, no cadastro, só levar ao painel quando a sessão realmente existir — se a confirmação por e-mail estiver ativa, mostrar o aviso para verificar a caixa de entrada.

## Detalhes técnicos

- `supabase--enable_email_auth` para habilitar o provedor de e-mail/senha.
- `supabase--configure_social_auth` com o provedor `google` (o fluxo do cliente já usa `lovable.auth.signInWithOAuth` com `redirect_uri` na origem pública, o que está correto).
- `src/routes/auth.tsx`: mapear erros comuns (`Invalid login credentials`, `User already registered`, `Email not confirmed`) para mensagens em português e condicionar o `navigate({ to: "/" })` do cadastro à presença de `data.session`.
- Verificação via Playwright na porta local: cadastro, logout e novo login.

Nenhuma tabela, dado ou funcionalidade existente é alterada.
