import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  AlertTriangle,
  ArrowUpRight,
  Building2,
  CalendarClock,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Eye,
  EyeOff,
  FileText,
  ListChecks,
  RotateCcw,
  ScrollText,
  ShieldAlert,
  SlidersHorizontal,
} from "lucide-react";
import { useMemo, useState, type ReactNode } from "react";

import { AppShell } from "@/components/sgla/AppShell";
import { BarList } from "@/components/sgla/charts";
import {
  EmptyState,
  Field,
  LoadingRows,
  PageHeader,
  Panel,
  Pill,
  StatCard,
  priorityTone,
  statusTone,
} from "@/components/sgla/primitives";
import {
  OVERALL_TONE,
  buildPendencies,
  countBy,
  deadlineLevel,
  isConditionOpen,
  isDocumentPending,
  isLicense,
  isProcessActive,
  overallStatus,
} from "@/lib/sgla/alerts";
import { useBlockLayout } from "@/lib/sgla/dashboard-layout";
import { useClients, useConditions, useDocuments, useProcesses } from "@/lib/sgla/db";
import { daysUntil, fmtDate, maskCnpj } from "@/lib/sgla/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Painel executivo | SGLA — Licenciamento Ambiental" },
      {
        name: "description",
        content:
          "Painel executivo do SGLA com indicadores de clientes, processos ambientais, condicionantes em vencimento e documentos técnicos emitidos.",
      },
      { property: "og:title", content: "Painel executivo | SGLA" },
      {
        property: "og:description",
        content:
          "Indicadores em tempo real de processos de licenciamento ambiental, prazos e documentos.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AppShell>
      <Dashboard />
    </AppShell>
  ),
});

type Block = { key: string; label: string; span?: string; node: ReactNode };

const KPI_KEYS = [
  "processos",
  "licencas",
  "condicionantes",
  "criticas",
  "documentos",
  "clientes",
] as const;

const SECTION_KEYS = [
  "grafico-licenca",
  "grafico-processo",
  "grafico-condicionante",
  "grafico-documento",
  "processos-recentes",
  "agenda",
  "carteira",
] as const;

function EditWrap({
  editing,
  label,
  hidden,
  onToggle,
  onUp,
  onDown,
  children,
}: {
  editing: boolean;
  label: string;
  hidden: boolean;
  onToggle: () => void;
  onUp: () => void;
  onDown: () => void;
  children: ReactNode;
}) {
  if (!editing) return <>{children}</>;
  return (
    <div
      className={cn(
        "relative rounded-2xl border border-dashed border-primary/40 p-1.5",
        hidden && "opacity-55",
      )}
    >
      <div className="mb-1.5 flex items-center justify-between gap-2 px-1.5">
        <span className="truncate text-[11px] font-medium tracking-wide text-muted-foreground uppercase">
          {label}
        </span>
        <div className="flex shrink-0 items-center gap-1">
          <button
            type="button"
            onClick={onUp}
            aria-label={`Mover ${label} para cima`}
            className="press grid size-7 place-items-center rounded-md border border-border"
          >
            <ChevronUp className="size-3.5" />
          </button>
          <button
            type="button"
            onClick={onDown}
            aria-label={`Mover ${label} para baixo`}
            className="press grid size-7 place-items-center rounded-md border border-border"
          >
            <ChevronDown className="size-3.5" />
          </button>
          <button
            type="button"
            onClick={onToggle}
            aria-label={hidden ? `Exibir ${label}` : `Ocultar ${label}`}
            className="press grid size-7 place-items-center rounded-md border border-border"
          >
            {hidden ? <EyeOff className="size-3.5" /> : <Eye className="size-3.5" />}
          </button>
        </div>
      </div>
      <div className="pointer-events-none">{children}</div>
    </div>
  );
}

function Dashboard() {
  const clients = useClients();
  const processes = useProcesses();
  const conditions = useConditions();
  const documents = useDocuments();
  const [editing, setEditing] = useState(false);

  const kpiLayout = useBlockLayout("sgla.dashboard.kpis", [...KPI_KEYS]);
  const sectionLayout = useBlockLayout("sgla.dashboard.sections", [...SECTION_KEYS]);

  const clientName = (id?: string | null) =>
    clients.data?.find((c) => c.id === id)?.legal_name ?? "Cliente não vinculado";

  const kpis = useMemo(() => {
    const p = processes.data ?? [];
    const c = conditions.data ?? [];
    const d = documents.data ?? [];
    const openConditions = c.filter(isConditionOpen);
    return {
      clients: clients.data?.length ?? 0,
      processes: p.length,
      active: p.filter(isProcessActive).length,
      granted: p.filter((x) => x.status === "Deferido").length,
      pending: openConditions.length,
      overdue: openConditions.filter((x) => (daysUntil(x.due_date) ?? 99) < 0).length,
      criticalConditions: openConditions.filter((x) => {
        const lvl = deadlineLevel(x.due_date);
        return lvl === "vencido" || lvl === "critico";
      }).length,
      expiringLicenses: p.filter((x) => {
        if (!isLicense(x)) return false;
        const days = daysUntil(x.expires_at);
        return days != null && days >= 0 && days <= 90;
      }).length,
      pendingDocs: d.filter(isDocumentPending).length,
      docs: d.length,
    };
  }, [clients.data, processes.data, conditions.data, documents.data]);

  const pendencies = useMemo(
    () =>
      buildPendencies({
        clients: clients.data ?? [],
        processes: processes.data ?? [],
        conditions: conditions.data ?? [],
        documents: documents.data ?? [],
      }),
    [clients.data, processes.data, conditions.data, documents.data],
  );

  const status = overallStatus(pendencies);

  const charts = useMemo(() => {
    const p = processes.data ?? [];
    const c = conditions.data ?? [];
    const d = documents.data ?? [];
    return {
      byLicense: countBy(p, (x) => x.license_type).slice(0, 6),
      byStatus: countBy(p, (x) => x.status),
      byCondition: countBy(c, (x) =>
        x.done ? "Concluída" : (daysUntil(x.due_date) ?? 99) < 0 ? "Vencida" : x.status,
      ),
      byDoc: countBy(d, (x) => x.status),
    };
  }, [processes.data, conditions.data, documents.data]);

  const agenda = useMemo(
    () =>
      (conditions.data ?? [])
        .filter((c) => isConditionOpen(c) && c.due_date)
        .sort((a, b) => String(a.due_date).localeCompare(String(b.due_date)))
        .slice(0, 6),
    [conditions.data],
  );

  const recent = useMemo(() => (processes.data ?? []).slice(0, 6), [processes.data]);

  const loading = clients.isLoading || processes.isLoading || conditions.isLoading;

  const kpiBlocks: Record<string, Block> = {
    processos: {
      key: "processos",
      label: "Processos ativos",
      node: (
        <StatCard
          label="Processos ativos"
          value={kpis.active}
          icon={ScrollText}
          tone="info"
          hint={`${kpis.processes} no total • ${kpis.granted} deferidos`}
        />
      ),
    },
    licencas: {
      key: "licencas",
      label: "Licenças a vencer",
      node: (
        <StatCard
          label="Licenças a vencer (90 dias)"
          value={kpis.expiringLicenses}
          icon={CalendarClock}
          tone={kpis.expiringLicenses ? "warning" : "success"}
          hint="Licenças deferidas com validade próxima"
        />
      ),
    },
    condicionantes: {
      key: "condicionantes",
      label: "Condicionantes pendentes",
      node: (
        <StatCard
          label="Condicionantes pendentes"
          value={kpis.pending}
          icon={CheckCircle2}
          tone={kpis.pending ? "warning" : "success"}
          hint={`${kpis.overdue} vencida(s)`}
        />
      ),
    },
    criticas: {
      key: "criticas",
      label: "Condicionantes críticas",
      node: (
        <StatCard
          label="Condicionantes críticas"
          value={kpis.criticalConditions}
          icon={ShieldAlert}
          tone={kpis.criticalConditions ? "danger" : "success"}
          hint="Vencidas ou com prazo em até 6 dias"
        />
      ),
    },
    documentos: {
      key: "documentos",
      label: "Documentos pendentes",
      node: (
        <StatCard
          label="Documentos pendentes"
          value={kpis.pendingDocs}
          icon={FileText}
          tone={kpis.pendingDocs ? "warning" : "success"}
          hint={`${kpis.docs} documento(s) no total`}
        />
      ),
    },
    clientes: {
      key: "clientes",
      label: "Empreendimentos",
      node: (
        <StatCard
          label="Empreendimentos"
          value={kpis.clients}
          icon={Building2}
          hint="Cadastrados na carteira"
        />
      ),
    },
  };

  const sectionBlocks: Record<string, Block> = {
    "grafico-licenca": {
      key: "grafico-licenca",
      label: "Processos por tipo de licença",
      node: (
        <Panel title="Processos por tipo de licença">
          <BarList data={charts.byLicense} tone="primary" />
        </Panel>
      ),
    },
    "grafico-processo": {
      key: "grafico-processo",
      label: "Processos por situação",
      node: (
        <Panel title="Processos por situação">
          <BarList data={charts.byStatus} tone="info" />
        </Panel>
      ),
    },
    "grafico-condicionante": {
      key: "grafico-condicionante",
      label: "Condicionantes por situação",
      node: (
        <Panel title="Condicionantes por situação">
          <BarList data={charts.byCondition} tone="warning" />
        </Panel>
      ),
    },
    "grafico-documento": {
      key: "grafico-documento",
      label: "Documentos por situação",
      node: (
        <Panel title="Documentos por situação">
          <BarList data={charts.byDoc} tone="success" />
        </Panel>
      ),
    },
    "processos-recentes": {
      key: "processos-recentes",
      label: "Processos recentes",
      span: "md:col-span-2",
      node: (
        <Panel
          title="Processos recentes"
          description="Últimas movimentações registradas na carteira."
          actions={
            <Link to="/processos" className="press text-xs font-medium text-primary">
              Ver todos
            </Link>
          }
        >
          {loading ? (
            <LoadingRows />
          ) : recent.length === 0 ? (
            <EmptyState
              icon={ScrollText}
              title="Nenhum processo cadastrado"
              description="Cadastre um cliente e abra o primeiro processo de licenciamento para acompanhar prazos e documentos."
            />
          ) : (
            <ul className="space-y-2">
              {recent.map((p, i) => (
                <motion.li
                  key={p.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.05 * i, duration: 0.35 }}
                >
                  <Link
                    to="/processos"
                    className="press lift ripple-host flex flex-col gap-2 rounded-xl border border-border bg-card/60 p-3.5 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{p.license_type}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {clientName(p.client_id)} • {p.agency ?? "Órgão não definido"}
                      </p>
                    </div>
                    <div className="flex shrink-0 flex-wrap items-center gap-2">
                      <Pill tone={priorityTone(p.priority)}>{p.priority}</Pill>
                      <Pill tone={statusTone(p.status)}>{p.status}</Pill>
                      <ArrowUpRight className="size-4 text-muted-foreground" />
                    </div>
                  </Link>
                </motion.li>
              ))}
            </ul>
          )}
        </Panel>
      ),
    },
    agenda: {
      key: "agenda",
      label: "Agenda de condicionantes",
      span: "md:col-span-2",
      node: (
        <Panel
          title="Agenda de condicionantes"
          description="Próximos vencimentos por ordem de prazo."
          actions={
            <Link to="/condicionantes" className="press text-xs font-medium text-primary">
              Gerenciar
            </Link>
          }
        >
          {loading ? (
            <LoadingRows rows={3} />
          ) : agenda.length === 0 ? (
            <EmptyState
              icon={CheckCircle2}
              title="Sem prazos em aberto"
              description="Todas as condicionantes com data definida estão cumpridas."
            />
          ) : (
            <ul className="space-y-2">
              {agenda.map((c, i) => {
                const d = daysUntil(c.due_date) ?? 0;
                const tone = d < 0 ? "danger" : d <= 15 ? "warning" : "info";
                return (
                  <motion.li
                    key={c.id}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.05 * i, duration: 0.35 }}
                    className="rounded-xl border border-border bg-card/60 p-3.5"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <p className="text-sm font-medium">{c.title}</p>
                      <Pill tone={tone}>
                        {d < 0 ? `${Math.abs(d)}d em atraso` : d === 0 ? "vence hoje" : `${d}d`}
                      </Pill>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {clientName(c.client_id)} • prazo {fmtDate(c.due_date)}
                    </p>
                  </motion.li>
                );
              })}
            </ul>
          )}
        </Panel>
      ),
    },
    carteira: {
      key: "carteira",
      label: "Carteira de clientes",
      span: "md:col-span-2 xl:col-span-4",
      node: (
        <Panel
          title="Carteira de clientes"
          description="Empreendimentos sob responsabilidade técnica."
          actions={
            <Link to="/clientes" className="press text-xs font-medium text-primary">
              Abrir cadastro
            </Link>
          }
        >
          {clients.isLoading ? (
            <LoadingRows rows={2} />
          ) : (clients.data?.length ?? 0) === 0 ? (
            <EmptyState
              icon={Building2}
              title="Nenhum cliente cadastrado"
              description="Cadastre um empreendimento manualmente ou pela consulta de CNPJ para começar."
            />
          ) : (
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {clients.data!.slice(0, 6).map((c) => (
                <Link
                  key={c.id}
                  to="/clientes"
                  className="press lift ripple-host rounded-xl border border-border bg-card/60 p-4"
                >
                  <p className="truncate text-sm font-medium">{c.legal_name}</p>
                  <p className="mt-0.5 truncate text-xs text-muted-foreground">
                    {c.cnpj ? maskCnpj(c.cnpj) : "CNPJ não informado"}
                  </p>
                  <dl className="mt-3 grid grid-cols-2 gap-2">
                    <Field label="Município" value={[c.city, c.uf].filter(Boolean).join("/")} />
                    <Field label="Situação" value={c.registration_status} />
                  </dl>
                </Link>
              ))}
            </div>
          )}
        </Panel>
      ),
    },
  };

  const visibleKpis = kpiLayout.order.filter((k) => editing || !kpiLayout.isHidden(k));
  const visibleSections = sectionLayout.order.filter((k) => editing || !sectionLayout.isHidden(k));

  return (
    <>
      <PageHeader
        title="Painel executivo"
        subtitle={
          editing
            ? "Modo de edição: reordene, oculte ou exiba os blocos do painel."
            : "Visão consolidada da carteira de licenciamento e da conformidade ambiental."
        }
        actions={
          <>
            {editing ? (
              <>
                <button
                  type="button"
                  onClick={() => {
                    kpiLayout.reset();
                    sectionLayout.reset();
                  }}
                  className="press ripple-host inline-flex items-center gap-2 rounded-lg border border-border px-3.5 py-2 text-sm font-medium"
                >
                  <RotateCcw className="size-4" /> Restaurar padrão
                </button>
                <button
                  type="button"
                  onClick={() => setEditing(false)}
                  className="press ripple-host inline-flex items-center gap-2 rounded-lg bg-primary px-3.5 py-2 text-sm font-medium text-primary-foreground"
                >
                  <Check className="size-4" /> Concluir edição
                </button>
              </>
            ) : (
              <>
                <Pill tone={OVERALL_TONE[status]}>Situação geral: {status}</Pill>
                <button
                  type="button"
                  onClick={() => setEditing(true)}
                  className="press ripple-host inline-flex items-center gap-2 rounded-lg border border-border px-3.5 py-2 text-sm font-medium"
                >
                  <SlidersHorizontal className="size-4" /> Editar painel
                </button>
                <Link
                  to="/pendencias"
                  className="press ripple-host inline-flex items-center gap-2 rounded-lg border border-border px-3.5 py-2 text-sm font-medium"
                >
                  <ListChecks className="size-4" /> Pendências
                </Link>
                <Link
                  to="/documentos"
                  className="press ripple-host inline-flex items-center gap-2 rounded-lg bg-primary px-3.5 py-2 text-sm font-medium text-primary-foreground"
                >
                  <FileText className="size-4" /> Emitir documento
                </Link>
              </>
            )}
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {visibleKpis.map((key) => {
          const block = kpiBlocks[key];
          if (!block) return null;
          return (
            <EditWrap
              key={key}
              editing={editing}
              label={block.label}
              hidden={kpiLayout.isHidden(key)}
              onToggle={() => kpiLayout.toggle(key)}
              onUp={() => kpiLayout.move(key, -1)}
              onDown={() => kpiLayout.move(key, 1)}
            >
              {block.node}
            </EditWrap>
          );
        })}
      </div>

      {pendencies.length && !editing ? (
        <Link
          to="/pendencias"
          className="press lift ripple-host mt-4 flex items-center justify-between gap-3 rounded-xl border border-warning/30 bg-warning/8 p-4"
        >
          <div className="flex items-center gap-3">
            <AlertTriangle className="size-4 shrink-0 text-warning" />
            <p className="text-sm">
              <span className="font-medium">{pendencies.length} pendência(s)</span> identificada(s)
              nos prazos e situações registradas.
            </p>
          </div>
          <ArrowUpRight className="size-4 shrink-0 text-muted-foreground" />
        </Link>
      ) : null}

      <div className="mt-5 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
        {visibleSections.map((key) => {
          const block = sectionBlocks[key];
          if (!block) return null;
          return (
            <div key={key} className={block.span}>
              <EditWrap
                editing={editing}
                label={block.label}
                hidden={sectionLayout.isHidden(key)}
                onToggle={() => sectionLayout.toggle(key)}
                onUp={() => sectionLayout.move(key, -1)}
                onDown={() => sectionLayout.move(key, 1)}
              >
                {block.node}
              </EditWrap>
            </div>
          );
        })}
      </div>
    </>
  );
}
