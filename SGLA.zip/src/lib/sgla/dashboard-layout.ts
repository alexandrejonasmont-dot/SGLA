import { useCallback, useEffect, useState } from "react";

export type LayoutState = {
  order: string[];
  hidden: string[];
};

function normalize(state: LayoutState, allKeys: string[]): LayoutState {
  const known = state.order.filter((k) => allKeys.includes(k));
  const missing = allKeys.filter((k) => !known.includes(k));
  return {
    order: [...known, ...missing],
    hidden: state.hidden.filter((k) => allKeys.includes(k)),
  };
}

/**
 * Persisted, user-editable ordering/visibility for dashboard blocks.
 * Reads localStorage only after hydration to avoid SSR mismatches.
 */
export function useBlockLayout(storageKey: string, allKeys: string[]) {
  const [state, setState] = useState<LayoutState>({ order: allKeys, hidden: [] });

  useEffect(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (!raw) return;
      const parsed = JSON.parse(raw) as Partial<LayoutState>;
      setState(
        normalize(
          { order: parsed.order ?? allKeys, hidden: parsed.hidden ?? [] },
          allKeys,
        ),
      );
    } catch {
      /* layout inválido: mantém o padrão */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storageKey]);

  const persist = useCallback(
    (next: LayoutState) => {
      setState(next);
      try {
        localStorage.setItem(storageKey, JSON.stringify(next));
      } catch {
        /* armazenamento indisponível */
      }
    },
    [storageKey],
  );

  const toggle = useCallback(
    (key: string) =>
      persist({
        order: state.order,
        hidden: state.hidden.includes(key)
          ? state.hidden.filter((k) => k !== key)
          : [...state.hidden, key],
      }),
    [persist, state],
  );

  const move = useCallback(
    (key: string, direction: -1 | 1) => {
      const order = [...state.order];
      const i = order.indexOf(key);
      const j = i + direction;
      if (i < 0 || j < 0 || j >= order.length) return;
      [order[i], order[j]] = [order[j]!, order[i]!];
      persist({ order, hidden: state.hidden });
    },
    [persist, state],
  );

  const reset = useCallback(() => {
    persist({ order: allKeys, hidden: [] });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [persist, allKeys.join("|")]);

  const isHidden = useCallback((key: string) => state.hidden.includes(key), [state.hidden]);

  return { order: state.order, isHidden, toggle, move, reset };
}
